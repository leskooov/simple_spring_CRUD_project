package ru.leskov.springcourse.dao;


import org.springframework.stereotype.Component;
import ru.leskov.springcourse.models.Person;

import java.util.ArrayList;
import java.util.List;

//посредник между БД и классом Person
@Component
public class PersonDAO {
    private static int PEOPLE_COUNT;
    private List<Person> people;

    {
        people = new ArrayList<>();

        people.add(new Person(++PEOPLE_COUNT,"Dmitry","Basketball"));
        people.add(new Person(++PEOPLE_COUNT,"Nikita","Football"));
        people.add(new Person(++PEOPLE_COUNT,"Vlad","Baseball"));
        people.add(new Person(++PEOPLE_COUNT,"Joel","Hockey"));
        people.add(new Person(++PEOPLE_COUNT,"Kate","Pool"));
        people.add(new Person(++PEOPLE_COUNT,"Johny","Swimming"));
    }

    public List<Person> index(){
        return people;
    }

    public Person show(int id){
        //получим 1 человека по ID из DAO и передадим на отображение в представление
        return people.stream().filter(person -> person.getId() == id).findAny().orElse(null);
    }

    public void save(Person person){
        person.setId(++PEOPLE_COUNT);
        people.add(person);
    }
}
