package ru.leskov.springcourse.models;

public class Person {
    private int id;
    private String name;
    private String nameHobby;

    public Person(int id, String name, String nameHobby) {
        this.id = id;
        this.name = name;
        this.nameHobby = nameHobby;
    }
    public Person(){

    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameHobby() {
        return nameHobby;
    }

    public void setNameHobby(String nameHobby) {
        this.nameHobby = nameHobby;
    }
}
